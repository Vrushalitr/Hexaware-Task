package com.hexaware.util;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBConnUtil {
    public static Connection getConnection() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            String connStr = DBPropertyUtil.getPropertyString("db.properties");
            return DriverManager.getConnection(connStr);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}