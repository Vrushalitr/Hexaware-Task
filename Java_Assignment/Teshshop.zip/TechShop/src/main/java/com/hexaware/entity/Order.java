package com.hexaware.entity;

import java.util.List;

public class Order {
    private int orderId;
    private Customer customer;
    private String orderDate; // Format: YYYY-MM-DD
    private double totalAmount;
    private String status;
    private List<OrderDetail> orderDetailsList;

    // Constructor
    public Order(int orderId, Customer customer, String orderDate, double totalAmount, String status, List<OrderDetail> orderDetailsList) {
        this.orderId = orderId;
        this.customer = customer;
        this.orderDate = orderDate;
        this.totalAmount = totalAmount;
        this.status = status;
        this.orderDetailsList = orderDetailsList;
    }

    // Getters
    public int getOrderId() {
        return orderId;
    }
    public Customer getCustomer() {
        return customer;
    }
    public String getOrderDate() {
        return orderDate;
    }
    public double getTotalAmount() {
        return totalAmount;
    }
    public String getStatus() {
        return status;
    }
    public List<OrderDetail> getOrderDetailsList() {
        return orderDetailsList;
    }
    // Setters
    public void setOrderId(int orderId) {
        this.orderId = orderId;
    }
    public void setCustomer(Customer customer) {
        this.customer = customer;
    }
    public void setOrderDate(String orderDate) {
        this.orderDate = orderDate;
    }
    public void setTotalAmount(double totalAmount) {
        this.totalAmount = totalAmount;
    }
    public void setStatus(String status) {
        this.status = status;
    }

    public void setOrderDetailsList(List<OrderDetail> orderDetailsList) {
        this.orderDetailsList = orderDetailsList;
    }

    // Optional utility method
    public void getOrderDetails() {
        System.out.println("Order ID: " + orderId);
        System.out.println("Customer ID: " + customer.getOldCustomerId());
        System.out.println("Order Date: " + orderDate);
        System.out.println("Total Amount: ₹" + totalAmount);
        System.out.println("Status: " + status);
        System.out.println("Order Items:");
        for (OrderDetail detail : orderDetailsList) {
            detail.getOrderDetailInfo();
        }
    }
}
