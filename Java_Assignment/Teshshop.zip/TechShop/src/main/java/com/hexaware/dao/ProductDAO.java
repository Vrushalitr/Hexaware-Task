package com.hexaware.dao;

import java.util.List;

import com.hexaware.entity.Product;

public interface ProductDAO {
    boolean insertProduct(Product product);
    Product getProductById(int productId);
    boolean updateProduct(Product product);
    boolean deleteProduct(int productId);
    List<Product> getAllProducts();
}
