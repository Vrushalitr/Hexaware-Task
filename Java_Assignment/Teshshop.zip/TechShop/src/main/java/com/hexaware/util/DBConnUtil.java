package com.hexaware.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;
import java.io.InputStream;

public class DBConnUtil {
    private static final String DB_URL = "jdbc:mysql://localhost:3306/techshop";
    private static final String DB_USER = "root";
    private static final String DB_PASS = "Vrushu@123";

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(DB_URL, DB_USER, DB_PASS);
    }
}
