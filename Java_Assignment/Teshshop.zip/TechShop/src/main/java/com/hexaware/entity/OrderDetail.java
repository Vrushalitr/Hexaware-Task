package com.hexaware.entity;

public class OrderDetail {

    private int orderDetailId;
    private int orderId;
    private Product product;
    private int quantity;

    // Constructor with all fields
    public OrderDetail(int orderDetailId, int orderId, Product product, int quantity) {
        this.orderDetailId = orderDetailId;
        this.orderId = orderId;
        this.product = product;
        this.quantity = quantity;
    }

    // Getters
    public int getOrderDetailId() { return orderDetailId; }
    public int getOrderId() { return orderId; }
    public Product getProduct() { return product; }
    public int getQuantity() { return quantity; }

    // Setters
    public void setOrderDetailId(int orderDetailId) { this.orderDetailId = orderDetailId; }
    public void setOrderId(int orderId) { this.orderId = orderId; }
    public void setProduct(Product product) { this.product = product; }
    public void setQuantity(int quantity) { this.quantity = quantity; }

    
    public double calculateSubtotal() {
        return product.getPrice() * quantity;
    }

    // Display order detail
    public void getOrderDetailInfo() {
        System.out.println("Product: " + product.getProductName());
        System.out.println("Quantity: " + quantity);
        System.out.println("Price per unit: ₹" + product.getPrice());
        System.out.println("Subtotal: ₹" + calculateSubtotal());
    }
}
