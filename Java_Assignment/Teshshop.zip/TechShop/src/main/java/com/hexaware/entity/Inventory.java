package com.hexaware.entity;

import java.time.LocalDate;

public class Inventory {

    private int inventoryId;
    private Product product;
    private int quantityInStock;
    private String lastStockUpdate;

    // Full Constructor
    public Inventory(int inventoryId, Product product, int quantityInStock, String lastStockUpdate) {
        this.inventoryId = inventoryId;
        this.product = product;
        this.quantityInStock = quantityInStock;
        this.lastStockUpdate = lastStockUpdate;
    }

    // Getters
    public int getInventoryId() {
        return inventoryId;
    }
    public Product getProduct() {
        return product;
    }
    public int getQuantityInStock() {
        return quantityInStock;
    }
    public String getLastStockUpdate() {
        return lastStockUpdate;
    }
    // Setters
    public void setInventoryId(int inventoryId) {
        this.inventoryId = inventoryId;
    }

    public void setProduct(Product product) {
        this.product = product;
    }
    public void setQuantityInStock(int quantityInStock) {
        this.quantityInStock = quantityInStock;
    }
    public void setLastStockUpdate(String lastStockUpdate) {
        this.lastStockUpdate = lastStockUpdate;
    }

   
    public void addToInventory(int quantity) {
        this.quantityInStock += quantity;
        updateStockDateToNow();
    }

    public void removeFromInventory(int quantity) {
        if (quantity <= quantityInStock) {
            this.quantityInStock -= quantity;
            updateStockDateToNow();
        } else {
            System.out.println("Insufficient stock to remove.");
        }
    }

    public void updateStockQuantity(int newQuantity) {
        this.quantityInStock = newQuantity;
        updateStockDateToNow();
    }

    public boolean isProductAvailable(int quantityToCheck) {
        return this.quantityInStock >= quantityToCheck;
    }

    public double getInventoryValue() {
        return product.getPrice() * quantityInStock;
    }

    private void updateStockDateToNow() {
        this.lastStockUpdate = LocalDate.now().toString();
    }

    public void displayInventoryDetails() {
        System.out.println("Inventory ID: " + inventoryId);
        System.out.println("Product ID: " + product.getProductId());
        System.out.println("Product Name: " + product.getProductName());
        System.out.println("Quantity in Stock: " + quantityInStock);
        System.out.println("Last Stock Update: " + lastStockUpdate);
        System.out.println("Stock Value: ₹" + getInventoryValue());
    }
}
