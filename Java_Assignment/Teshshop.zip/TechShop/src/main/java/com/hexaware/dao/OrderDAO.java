package com.hexaware.dao;

import java.util.List;

import com.hexaware.entity.Order;

public interface OrderDAO {
    boolean placeOrder(Order order);
    Order getOrderById(int orderId);
    boolean updateOrder(Order order);
    boolean cancelOrder(int orderId);
    List<Order> getOrdersByCustomerId(int customerId);
}
