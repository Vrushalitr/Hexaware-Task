package com.hexaware.dao.impl;

import com.hexaware.dao.OrderDAO;
import com.hexaware.entity.Customer;
import com.hexaware.entity.Order;
import com.hexaware.entity.OrderDetail;
import com.hexaware.entity.Product;
import com.hexaware.util.DBConnUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class OrderDAOImpl implements OrderDAO {

    private final ProductDAOImpl productDAO = new ProductDAOImpl();
    private final CustomerDAOImpl customerDAO = new CustomerDAOImpl();

    @Override
    public boolean placeOrder(Order order) {
        try (Connection conn = DBConnUtil.getConnection()) {
            conn.setAutoCommit(false);

            String orderSQL = "INSERT INTO Orders (orderId, customerId, orderDate, totalAmount, status) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement orderStmt = conn.prepareStatement(orderSQL);
            orderStmt.setInt(1, order.getOrderId());
            orderStmt.setInt(2, order.getCustomer().getOldCustomerId());
            orderStmt.setString(3, order.getOrderDate());
            orderStmt.setDouble(4, order.getTotalAmount());
            orderStmt.setString(5, order.getStatus());
            orderStmt.executeUpdate();

            String detailSQL = "INSERT INTO OrderDetails (orderDetailId, orderId, productId, quantity) VALUES (?, ?, ?, ?)";
            PreparedStatement detailStmt = conn.prepareStatement(detailSQL);

            for (OrderDetail detail : order.getOrderDetailsList()) {
                detailStmt.setInt(1, detail.getOrderDetailId());
                detailStmt.setInt(2, order.getOrderId());
                detailStmt.setInt(3, detail.getProduct().getProductId());
                detailStmt.setInt(4, detail.getQuantity());
                detailStmt.addBatch();
            }

            detailStmt.executeBatch();
            conn.commit();
            return true;

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    @Override
    public Order getOrderById(int orderId) {
        try (Connection conn = DBConnUtil.getConnection()) {
            String sql = "SELECT * FROM Orders WHERE orderId = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, orderId);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                int customerId = rs.getInt("customerId");
                Customer customer = customerDAO.getCustomerByOldId(customerId);
                String orderDate = rs.getString("orderDate");
                double totalAmount = rs.getDouble("totalAmount");
                String status = rs.getString("status");

                // Get order details
                String detailSQL = "SELECT * FROM OrderDetails WHERE orderId = ?";
                PreparedStatement detailStmt = conn.prepareStatement(detailSQL);
                detailStmt.setInt(1, orderId);
                ResultSet detailRs = detailStmt.executeQuery();

                List<OrderDetail> orderDetails = new ArrayList<>();

                while (detailRs.next()) {
                    int orderDetailId = detailRs.getInt("orderDetailId");
                    int productId = detailRs.getInt("productId");
                    int qty = detailRs.getInt("quantity");

                    Product product = productDAO.getProductById(productId);
                    OrderDetail detail = new OrderDetail(orderDetailId, orderId, product, qty);
                    orderDetails.add(detail);
                }

                return new Order(orderId, customer, orderDate, totalAmount, status, orderDetails);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public boolean cancelOrder(int orderId) {
        String sql = "UPDATE Orders SET status = 'Cancelled' WHERE orderId = ?";
        try (Connection conn = DBConnUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, orderId);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

	@Override
	public boolean updateOrder(Order order) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public List<Order> getOrdersByCustomerId(int customerId) {
		// TODO Auto-generated method stub
		return null;
	}
}
