package com.hexaware.dao;

import java.util.List;

import com.hexaware.entity.Inventory;
import com.hexaware.entity.Product;

public interface InventoryDAO {
    boolean addProductToInventory(Product product);
    boolean updateInventory(Product product);
    boolean removeProductFromInventory(int productId);
    int getStockQuantity(int productId);
    List<Product> listAllProducts();
    List<Inventory> listLowStockProducts(int threshold);
    List<Inventory> listOutOfStockProducts();
	boolean insertInventory(Inventory inventory);
	Inventory getInventoryByProductId(int productId);
	boolean updateStockQuantity(int productId, int newQuantity);
	List<Inventory> listAllInventory();
}
