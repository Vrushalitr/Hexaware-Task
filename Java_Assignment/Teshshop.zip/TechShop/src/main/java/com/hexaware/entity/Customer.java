package com.hexaware.entity;

public class Customer {
    private int oldCustomerId;
    private String firstName;
    private String lastName;
    private String email;
    private String phone;
    private String address;
    private int orderCounter;

    public Customer(int oldCustomerId, String firstName, String lastName, String email, String phone, String address, int orderCounter) {
        this.oldCustomerId = oldCustomerId;
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.phone = phone;
        this.address = address;
        this.orderCounter = orderCounter;
    }

    // Getters and Setters
    public int getOldCustomerId() { return oldCustomerId; }
    public String getFirstName() { return firstName; }
    public String getLastName() { return lastName; }
    public String getEmail() { return email; }
    public String getPhone() { return phone; }
    public String getAddress() { return address; }
    public int getOrderCounter() { return orderCounter; }

    public void setEmail(String email) { this.email = email; }
    public void setPhone(String phone) { this.phone = phone; }
    public void setAddress(String address) { this.address = address; }
    public void setOrderCounter(int orderCounter) { this.orderCounter = orderCounter; }

    // OOP Methods
    public void calculateTotalOrders() {
        System.out.println("Total Orders Placed: " + orderCounter);
    }

    public void getCustomerDetails() {
        System.out.println("Customer ID: " + oldCustomerId);
        System.out.println("Name: " + firstName + " " + lastName);
        System.out.println("Email: " + email);
        System.out.println("Phone: " + phone);
        System.out.println("Address: " + address);
        System.out.println("Order Count: " + orderCounter);
    }

    public void updateCustomerInfo(String newEmail, String newPhone, String newAddress) {
        this.email = newEmail;
        this.phone = newPhone;
        this.address = newAddress;
        System.out.println("Customer info updated successfully.");
    }
}
