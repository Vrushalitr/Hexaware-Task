package com.hexaware.entity;

public class Product {

    private int productId;
    private String productName;
    private String description;
    private double price;

    // Constructor
    public Product(int productId, String productName, String description, double price) {
        this.productId = productId;
        this.productName = productName;
        this.description = description;
        this.price = price;
    }

    // Getters
    public int getProductId() {
        return productId;
    }

    public String getProductName() {
        return productName;
    }

    public String getDescription() {
        return description;
    }

    public double getPrice() {
        return price;
    }

    // Setters
    public void setProductId(int productId) {
        this.productId = productId;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    // Functional methods
    public void getProductDetails() {
        System.out.println("Product ID: " + productId);
        System.out.println("Name: " + productName);
        System.out.println("Description: " + description);
        System.out.println("Price: ₹" + price);
    }

    public void updateProductInfo(String newDescription, double newPrice) {
        this.description = newDescription;
        this.price = newPrice;
        System.out.println("Product info updated successfully.");
    }
}
