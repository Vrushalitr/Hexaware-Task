package com.hexaware.dao.impl;

import com.hexaware.dao.InventoryDAO;
import com.hexaware.entity.Inventory;
import com.hexaware.entity.Product;
import com.hexaware.util.DBConnUtil;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class InventoryDAOImpl implements InventoryDAO {

    private final ProductDAOImpl productDAO = new ProductDAOImpl();

    @Override
    public boolean insertInventory(Inventory inventory) {
        String sql = "INSERT INTO Inventory (inventoryId, productId, quantityInStock, lastStockUpdate) VALUES (?, ?, ?, ?)";
        try (Connection conn = DBConnUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, inventory.getInventoryId());
            stmt.setInt(2, inventory.getProduct().getProductId());
            stmt.setInt(3, inventory.getQuantityInStock());
            stmt.setDate(4, Date.valueOf(inventory.getLastStockUpdate()));

            return stmt.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    @Override
    public Inventory getInventoryByProductId(int productId) {
        String sql = "SELECT * FROM Inventory WHERE productId = ?";
        try (Connection conn = DBConnUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, productId);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                Product product = productDAO.getProductById(productId);
                return new Inventory(
                        rs.getInt("inventoryId"),
                        product,
                        rs.getInt("quantityInStock"),
                        rs.getString("lastStockUpdate")
                );
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public boolean updateStockQuantity(int productId, int newQuantity) {
        String sql = "UPDATE Inventory SET quantityInStock = ?, lastStockUpdate = ? WHERE productId = ?";
        try (Connection conn = DBConnUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, newQuantity);
            stmt.setDate(2, Date.valueOf(LocalDate.now()));
            stmt.setInt(3, productId);

            return stmt.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    @Override
    public List<Inventory> listLowStockProducts(int threshold) {
        String sql = "SELECT * FROM Inventory WHERE quantityInStock < ?";
        List<Inventory> list = new ArrayList<>();

        try (Connection conn = DBConnUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, threshold);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                Product product = productDAO.getProductById(rs.getInt("productId"));
                Inventory inv = new Inventory(
                        rs.getInt("inventoryId"),
                        product,
                        rs.getInt("quantityInStock"),
                        rs.getString("lastStockUpdate")
                );
                list.add(inv);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    @Override
    public List<Inventory> listOutOfStockProducts() {
        String sql = "SELECT * FROM Inventory WHERE quantityInStock = 0";
        List<Inventory> list = new ArrayList<>();

        try (Connection conn = DBConnUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                Product product = productDAO.getProductById(rs.getInt("productId"));
                Inventory inv = new Inventory(
                        rs.getInt("inventoryId"),
                        product,
                        rs.getInt("quantityInStock"),
                        rs.getString("lastStockUpdate")
                );
                list.add(inv);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    @Override
    public List<Inventory> listAllInventory() {
        String sql = "SELECT * FROM Inventory";
        List<Inventory> list = new ArrayList<>();

        try (Connection conn = DBConnUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                Product product = productDAO.getProductById(rs.getInt("productId"));
                Inventory inv = new Inventory(
                        rs.getInt("inventoryId"),
                        product,
                        rs.getInt("quantityInStock"),
                        rs.getString("lastStockUpdate")
                );
                list.add(inv);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    @Override
    public boolean addProductToInventory(Product product) {
        // Default to quantity 0 since quantityInStock is not in Product
        Inventory inv = new Inventory(0, product, 0, LocalDate.now().toString());
        return insertInventory(inv);
    }

    @Override
    public boolean updateInventory(Product product) {
        // Same: use default or external stock value
        Inventory existing = getInventoryByProductId(product.getProductId());
        if (existing != null) {
            return updateStockQuantity(product.getProductId(), existing.getQuantityInStock());
        }
        return false;
    }

    @Override
    public boolean removeProductFromInventory(int productId) {
        String sql = "DELETE FROM Inventory WHERE productId = ?";
        try (Connection conn = DBConnUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, productId);
            return stmt.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    @Override
    public int getStockQuantity(int productId) {
        Inventory inv = getInventoryByProductId(productId);
        return inv != null ? inv.getQuantityInStock() : 0;
    }

    @Override
    public List<Product> listAllProducts() {
        List<Product> products = new ArrayList<>();
        List<Inventory> inventoryList = listAllInventory();
        for (Inventory inv : inventoryList) {
            products.add(inv.getProduct());
        }
        return products;
    }
}
