package com.hexaware.dao;

import com.hexaware.entity.Customer;

public interface CustomerDAO {
    boolean insertCustomer(Customer customer);
    Customer getCustomerById(int customerId);
    boolean updateCustomer(Customer customer);
    boolean deleteCustomer(int customerId);
}
