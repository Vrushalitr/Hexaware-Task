package com.hexaware.main;

import com.hexaware.dao.impl.CustomerDAOImpl;
import com.hexaware.dao.impl.OrderDAOImpl;
import com.hexaware.dao.impl.ProductDAOImpl;
import com.hexaware.entity.Customer;
import com.hexaware.entity.Order;
import com.hexaware.entity.OrderDetail;
import com.hexaware.entity.Product;

import java.util.*;

public class MainModule {

    private static final Scanner scanner = new Scanner(System.in);
    private static final CustomerDAOImpl customerDAO = new CustomerDAOImpl();
    private static final ProductDAOImpl productDAO = new ProductDAOImpl();
    private static final OrderDAOImpl orderDAO = new OrderDAOImpl();

    public static void main(String[] args) {
        while (true) {
            System.out.println("\n=== TechShop Management Menu ===");
            System.out.println("1. Register Customer");
            System.out.println("2. Add Product");
            System.out.println("3. Place Order");
            System.out.println("4. View Order by ID");
            System.out.println("5. Cancel Order");
            System.out.println("6. Exit");
            System.out.print("Enter choice: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); // consume newline

            switch (choice) {
                case 1 -> registerCustomer();
                case 2 -> addProduct();
                case 3 -> placeOrder();
                case 4 -> viewOrder();
                case 5 -> cancelOrder();
                case 6 -> {
                    System.out.println("Exiting... Thank you!");
                    return;
                }
                default -> System.out.println("Invalid choice.");
            }
        }
    }

    private static void registerCustomer() {
        System.out.print("Old Customer ID: ");
        int oldId = scanner.nextInt();
        scanner.nextLine();
        System.out.print("First Name: ");
        String fname = scanner.nextLine();
        System.out.print("Last Name: ");
        String lname = scanner.nextLine();
        System.out.print("Email: ");
        String email = scanner.nextLine();
        System.out.print("Phone: ");
        String phone = scanner.nextLine();
        System.out.print("Address: ");
        String addr = scanner.nextLine();
        System.out.print("Order Counter: ");
        int counter = scanner.nextInt();

        Customer customer = new Customer(oldId, fname, lname, email, phone, addr, counter);
        boolean success = customerDAO.insertCustomer(customer);
        System.out.println(success ? "Customer registered successfully." : "Registration failed.");
    }

    private static void addProduct() {
        System.out.print("Product ID: ");
        int pid = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Product Name: ");
        String name = scanner.nextLine();
        System.out.print("Description: ");
        String desc = scanner.nextLine();
        System.out.print("Price: ");
        double price = scanner.nextDouble();
        scanner.nextLine();

        Product product = new Product(pid, name, desc, price);
        boolean success = productDAO.insertProduct(product);
        System.out.println(success ? "Product added successfully." : "Failed to add product.");
    }

    private static void placeOrder() {
        System.out.print("Order ID: ");
        int orderId = scanner.nextInt();

        System.out.print("Customer Old ID: ");
        int custId = scanner.nextInt();
        scanner.nextLine();
        Customer cust = customerDAO.getCustomerByOldId(custId);
        if (cust == null) {
            System.out.println("Customer not found.");
            return;
        }

        System.out.print("Order Date (yyyy-MM-dd): ");
        String date = scanner.nextLine();
        System.out.print("Order Status: ");
        String status = scanner.nextLine();

        List<OrderDetail> details = new ArrayList<>();
        double total = 0;

        while (true) {
            System.out.print("Order Detail ID (or 0 to finish): ");
            int orderDetailId = scanner.nextInt();
            if (orderDetailId == 0) break;

            System.out.print("Product ID: ");
            int productId = scanner.nextInt();
            Product product = productDAO.getProductById(productId);
            if (product == null) {
                System.out.println("Product not found.");
                continue;
            }

            System.out.print("Quantity: ");
            int qty = scanner.nextInt();

            OrderDetail detail = new OrderDetail(orderDetailId, orderId, product, qty);
            details.add(detail);
            total += detail.calculateSubtotal();
        }

        Order order = new Order(orderId, cust, date, total, status, details);
        boolean success = orderDAO.placeOrder(order);
        System.out.println(success ? "Order placed successfully." : "Order placement failed.");
    }

    private static void viewOrder() {
        System.out.print("Enter Order ID: ");
        int oid = scanner.nextInt();
        Order order = orderDAO.getOrderById(oid);

        if (order != null) {
            System.out.println("\n=== Order Details ===");
            System.out.println("Order ID: " + order.getOrderId());
            System.out.println("Customer: " + order.getCustomer().getFirstName() + " " + order.getCustomer().getLastName());
            System.out.println("Date: " + order.getOrderDate());
            System.out.println("Status: " + order.getStatus());
            System.out.println("Total Amount: ₹" + order.getTotalAmount());
            System.out.println("Items:");
            for (OrderDetail od : order.getOrderDetailsList()) {
                od.getOrderDetailInfo();
                System.out.println("-----");
            }
        } else {
            System.out.println("Order not found.");
        }
    }

    private static void cancelOrder() {
        System.out.print("Enter Order ID to cancel: ");
        int orderId = scanner.nextInt();
        boolean success = orderDAO.cancelOrder(orderId);
        System.out.println(success ? "Order cancelled." : "Cancel failed.");
    }
}
