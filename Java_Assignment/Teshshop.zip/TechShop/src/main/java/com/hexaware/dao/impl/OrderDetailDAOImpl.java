package com.hexaware.dao.impl;

import com.hexaware.dao.OrderDetailDAO;
import com.hexaware.dao.ProductDAO;
import com.hexaware.entity.OrderDetail;
import com.hexaware.entity.Product;
import com.hexaware.util.DBConnUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class OrderDetailDAOImpl implements OrderDetailDAO {

    private final ProductDAO productDAO = new ProductDAOImpl(); // Ensure ProductDAOImpl implements ProductDAO

    @Override
    public boolean insertOrderDetail(OrderDetail detail) {
        String sql = "INSERT INTO OrderDetails (orderDetailId, orderId, productId, quantity) VALUES (?, ?, ?, ?)";
        try (Connection conn = DBConnUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, detail.getOrderDetailId());
            stmt.setInt(2, detail.getOrderId());
            stmt.setInt(3, detail.getProduct().getProductId());
            stmt.setInt(4, detail.getQuantity());

            return stmt.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    @Override
    public List<OrderDetail> getOrderDetailsByOrderId(int orderId) {
        List<OrderDetail> details = new ArrayList<>();
        String sql = "SELECT * FROM OrderDetails WHERE orderId = ?";
        try (Connection conn = DBConnUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, orderId);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                int orderDetailId = rs.getInt("orderDetailId");
                int productId = rs.getInt("productId");
                int quantity = rs.getInt("quantity");

                Product product = productDAO.getProductById(productId);
                OrderDetail detail = new OrderDetail(orderDetailId, orderId, product, quantity); // Valid constructor
                details.add(detail);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return details;
    }

    public boolean deleteOrderDetailsByOrderId(int orderId) {
        String sql = "DELETE FROM OrderDetails WHERE orderId = ?";
        try (Connection conn = DBConnUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, orderId);
            return stmt.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

	@Override
	public boolean updateOrderDetail(OrderDetail orderDetail) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean deleteOrderDetail(int orderDetailId) {
		// TODO Auto-generated method stub
		return false;
	}
}
