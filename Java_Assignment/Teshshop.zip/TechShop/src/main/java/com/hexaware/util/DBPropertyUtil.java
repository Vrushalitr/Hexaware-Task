package com.hexaware.util;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class DBPropertyUtil {
    public static Properties loadPropertiesFile(String fileName) throws IOException {
        Properties prop = new Properties();
        try (InputStream inputStream = DBPropertyUtil.class.getClassLoader().getResourceAsStream(fileName)) {
            if (inputStream != null) {
                prop.load(inputStream);
            } else {
                throw new IOException("Property file '" + fileName + "' not found in the classpath");
            }
        }
        return prop;
    }
}
