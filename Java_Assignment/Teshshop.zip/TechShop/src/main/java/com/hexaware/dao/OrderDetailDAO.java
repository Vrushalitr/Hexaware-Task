package com.hexaware.dao;

import java.util.List;

import com.hexaware.entity.OrderDetail;

public interface OrderDetailDAO {
    boolean insertOrderDetail(OrderDetail orderDetail);
    boolean updateOrderDetail(OrderDetail orderDetail);
    boolean deleteOrderDetail(int orderDetailId);
    List<OrderDetail> getOrderDetailsByOrderId(int orderId);
}
