package com.hexaware.dao.impl;

import com.hexaware.dao.CustomerDAO;
import com.hexaware.entity.Customer;
import com.hexaware.util.DBConnUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class CustomerDAOImpl implements CustomerDAO {

    @Override
    public boolean insertCustomer(Customer customer) {
        try (Connection conn = DBConnUtil.getConnection()) {
            String sql = "INSERT INTO Customers (oldCustomerId, firstName, lastName, email, phone, address, orderCounter) VALUES (?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, customer.getOldCustomerId());
            stmt.setString(2, customer.getFirstName());
            stmt.setString(3, customer.getLastName());
            stmt.setString(4, customer.getEmail());
            stmt.setString(5, customer.getPhone());
            stmt.setString(6, customer.getAddress());
            stmt.setInt(7, customer.getOrderCounter());
            return stmt.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    @Override
    public Customer getCustomerById(int customerId) {
        try (Connection conn = DBConnUtil.getConnection()) {
            String sql = "SELECT * FROM Customers WHERE customerId = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, customerId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return new Customer(
                    rs.getInt("oldCustomerId"),
                    rs.getString("firstName"),
                    rs.getString("lastName"),
                    rs.getString("email"),
                    rs.getString("phone"),
                    rs.getString("address"),
                    rs.getInt("orderCounter")
                );
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    // Used in OrderDAOImpl
    public Customer getCustomerByOldId(int oldCustomerId) {
        try (Connection conn = DBConnUtil.getConnection()) {
            String sql = "SELECT * FROM Customers WHERE oldCustomerId = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, oldCustomerId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return new Customer(
                    rs.getInt("oldCustomerId"),
                    rs.getString("firstName"),
                    rs.getString("lastName"),
                    rs.getString("email"),
                    rs.getString("phone"),
                    rs.getString("address"),
                    rs.getInt("orderCounter")
                );
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public boolean updateCustomer(Customer customer) {
        try (Connection conn = DBConnUtil.getConnection()) {
            String sql = "UPDATE Customers SET firstName = ?, lastName = ?, email = ?, phone = ?, address = ?, orderCounter = ? WHERE oldCustomerId = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, customer.getFirstName());
            stmt.setString(2, customer.getLastName());
            stmt.setString(3, customer.getEmail());
            stmt.setString(4, customer.getPhone());
            stmt.setString(5, customer.getAddress());
            stmt.setInt(6, customer.getOrderCounter());
            stmt.setInt(7, customer.getOldCustomerId());
            return stmt.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    @Override
    public boolean deleteCustomer(int customerId) {
        try (Connection conn = DBConnUtil.getConnection()) {
            String sql = "DELETE FROM Customers WHERE customerId = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, customerId);
            return stmt.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
}
