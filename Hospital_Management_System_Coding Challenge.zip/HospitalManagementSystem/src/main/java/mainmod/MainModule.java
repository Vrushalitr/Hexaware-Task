package mainmod;

import dao.HospitalServiceImpl;
import entity.Appointment;

import java.util.List;
import java.util.Scanner;

public class MainModule {
    public static void main(String[] args) {
        HospitalServiceImpl service = new HospitalServiceImpl();
        Scanner sc = new Scanner(System.in);

        while (true) {
            System.out.println("\n=== Hospital Management Menu ===");
            System.out.println("1. Get Appointment by ID");
            System.out.println("2. Get Appointments for Patient");
            System.out.println("3. Get Appointments for Doctor");
            System.out.println("4. Schedule Appointment");
            System.out.println("5. Update Appointment");
            System.out.println("6. Cancel Appointment");
            System.out.println("7. Exit");
            System.out.print("Enter your choice: ");
            int choice = sc.nextInt();

            try {
                switch (choice) {
                    case 1:
                        System.out.print("Enter Appointment ID: ");
                        int id1 = sc.nextInt();
                        Appointment a = service.getAppointmentById(id1);
                        System.out.println(a != null ? a : "No appointment found.");
                        break;
                    case 2:
                        System.out.print("Enter Patient ID: ");
                        int pid1 = sc.nextInt();
                        List<Appointment> appts1 = service.getAppointmentsForPatient(pid1);
                        appts1.forEach(System.out::println);
                        break;
                    case 3:
                        System.out.print("Enter Doctor ID: ");
                        int did1 = sc.nextInt();
                        List<Appointment> appts2 = service.getAppointmentsForDoctor(did1);
                        appts2.forEach(System.out::println);
                        break;
                    case 4:
                        System.out.print("Enter Appointment ID: ");
                        int aid = sc.nextInt();
                        System.out.print("Enter Patient ID: ");
                        int pid = sc.nextInt();
                        System.out.print("Enter Doctor ID: ");
                        int did = sc.nextInt();
                        sc.nextLine();  // consume newline
                        System.out.print("Enter Date: ");
                        String date = sc.nextLine();
                        System.out.print("Enter Description: ");
                        String desc = sc.nextLine();
                        Appointment appt = new Appointment(aid, pid, did, date, desc);
                        System.out.println(service.scheduleAppointment(appt) ? "Scheduled" : "Failed");
                        break;
                    case 5:
                        System.out.print("Enter Appointment ID to Update: ");
                        int uaid = sc.nextInt();
                        System.out.print("Enter new Patient ID: ");
                        int upid = sc.nextInt();
                        System.out.print("Enter new Doctor ID: ");
                        int udid = sc.nextInt();
                        sc.nextLine();
                        System.out.print("Enter new Date: ");
                        String udate = sc.nextLine();
                        System.out.print("Enter new Description: ");
                        String udesc = sc.nextLine();
                        Appointment uappt = new Appointment(uaid, upid, udid, udate, udesc);
                        System.out.println(service.updateAppointment(uappt) ? "Updated" : "Update failed");
                        break;
                    case 6:
                        System.out.print("Enter Appointment ID to cancel: ");
                        int cancelId = sc.nextInt();
                        System.out.println(service.cancelAppointment(cancelId) ? "Cancelled" : "Cancel failed");
                        break;
                    case 7:
                        System.out.println("Exiting...");
                        return;
                    default:
                        System.out.println("Invalid choice.");
                }
            } catch (Exception e) {
                System.out.println("Unexpected error: " + e.getMessage());
            }
        }
    }
}
