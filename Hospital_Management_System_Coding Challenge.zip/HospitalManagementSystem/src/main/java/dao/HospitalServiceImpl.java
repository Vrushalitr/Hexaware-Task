package dao;

import entity.Appointment;
import util.DBConnUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class HospitalServiceImpl implements IHospitalService {

    private Connection getConnection() throws SQLException {
        return DBConnUtil.getConnection();
    }

    @Override
    public Appointment getAppointmentById(int appointmentId) {
        String sql = "SELECT * FROM Appointment WHERE appointmentId = ?";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, appointmentId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return new Appointment(
                    rs.getInt("appointmentId"),
                    rs.getInt("patientId"),
                    rs.getInt("doctorId"),
                    rs.getString("appointmentDate"),
                    rs.getString("description")
                );
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public List<Appointment> getAppointmentsForPatient(int patientId) {
        List<Appointment> list = new ArrayList<>();
        String sql = "SELECT * FROM Appointment WHERE patientId = ?";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, patientId);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                list.add(new Appointment(
                    rs.getInt("appointmentId"),
                    rs.getInt("patientId"),
                    rs.getInt("doctorId"),
                    rs.getString("appointmentDate"),
                    rs.getString("description")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    @Override
    public List<Appointment> getAppointmentsForDoctor(int doctorId) {
        List<Appointment> list = new ArrayList<>();
        String sql = "SELECT * FROM Appointment WHERE doctorId = ?";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, doctorId);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                list.add(new Appointment(
                    rs.getInt("appointmentId"),
                    rs.getInt("patientId"),
                    rs.getInt("doctorId"),
                    rs.getString("appointmentDate"),
                    rs.getString("description")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    @Override
    public boolean scheduleAppointment(Appointment appt) {
        try (Connection conn = getConnection()) {
            // Check if patient exists
            if (!recordExists(conn, "Patient", "patientId", appt.getPatientId())) {
                System.out.println("Patient ID does not exist.");
                return false;
            }

            // Check if doctor exists
            if (!recordExists(conn, "Doctor", "doctorId", appt.getDoctorId())) {
                System.out.println("Doctor ID does not exist.");
                return false;
            }

            // Proceed to schedule appointment
            String sql = "INSERT INTO Appointment (appointmentId, patientId, doctorId, appointmentDate, description) VALUES (?, ?, ?, ?, ?)";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setInt(1, appt.getAppointmentId());
                stmt.setInt(2, appt.getPatientId());
                stmt.setInt(3, appt.getDoctorId());
                stmt.setString(4, appt.getAppointmentDate());
                stmt.setString(5, appt.getDescription());
                int rowsAffected = stmt.executeUpdate();
                return rowsAffected > 0;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean updateAppointment(Appointment appt) {
        try (Connection conn = getConnection()) {
            // Check if appointment exists
            if (!recordExists(conn, "Appointment", "appointmentId", appt.getAppointmentId())) {
                System.out.println("Appointment ID does not exist.");
                return false;
            }

            // Check if patient exists
            if (!recordExists(conn, "Patient", "patientId", appt.getPatientId())) {
                System.out.println("Patient ID does not exist.");
                return false;
            }

            // Check if doctor exists
            if (!recordExists(conn, "Doctor", "doctorId", appt.getDoctorId())) {
                System.out.println("Doctor ID does not exist.");
                return false;
            }

            // Proceed to update appointment
            String sql = "UPDATE Appointment SET patientId = ?, doctorId = ?, appointmentDate = ?, description = ? WHERE appointmentId = ?";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setInt(1, appt.getPatientId());
                stmt.setInt(2, appt.getDoctorId());
                stmt.setString(3, appt.getAppointmentDate());
                stmt.setString(4, appt.getDescription());
                stmt.setInt(5, appt.getAppointmentId());
                int rowsAffected = stmt.executeUpdate();
                return rowsAffected > 0;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean cancelAppointment(int appointmentId) {
        try (Connection conn = getConnection()) {
            // Check if appointment exists
            if (!recordExists(conn, "Appointment", "appointmentId", appointmentId)) {
                System.out.println("Appointment ID does not exist.");
                return false;
            }

            // Proceed to delete appointment
            String sql = "DELETE FROM Appointment WHERE appointmentId = ?";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setInt(1, appointmentId);
                int rowsAffected = stmt.executeUpdate();
                return rowsAffected > 0;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    private boolean recordExists(Connection conn, String tableName, String columnName, int id) throws SQLException {
        String sql = "SELECT 1 FROM " + tableName + " WHERE " + columnName + " = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            return rs.next();
        }
    }
}
